"""
Utility scripts for PTCC
"""