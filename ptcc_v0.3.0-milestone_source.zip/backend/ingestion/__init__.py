"""
Data ingestion system for PTCC
"""