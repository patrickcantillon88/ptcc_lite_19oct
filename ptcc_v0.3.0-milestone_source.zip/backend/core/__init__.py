"""
Core backend functionality
"""