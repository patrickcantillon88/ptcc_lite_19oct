"""
Data models for PTCC
"""